package com.dahabmarket.app;
import android.app.Activity; import android.os.Bundle; import android.webkit.*; import androidx.webkit.WebViewAssetLoader;
public class MainActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b); WebView w=new WebView(this); w.getSettings().setJavaScriptEnabled(true); w.getSettings().setDomStorageEnabled(true);
 WebViewAssetLoader l=new WebViewAssetLoader.Builder().addPathHandler("/web/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
 w.setWebViewClient(new WebViewClient(){public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){return l.shouldInterceptRequest(r.getUrl());}});
 setContentView(w); w.loadUrl("https://appassets.androidplatform.net/web/index.html");}
}